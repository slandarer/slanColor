%% demo4 : Apply the slanCM colormap to the simulated terrain surface with default lighting and shading
X  = linspace(0, 1, 200)';
CL = (-cos(X*2*pi) + 1).^.2;
r  = (X - .5)'.^2 + (X - .5).^2;
surf(X, X', abs(ifftn(exp(7i*rand(200))./r.^.9)).*(CL*CL')*30, 'EdgeColor','none')

colormap(slanCM('terrain'))
light; material dull
view(59.1823, 56.1559)

% Decorate the axes
ax = gca;
ax.Projection    = 'perspective';
ax.LineWidth     = .8;
ax.XMinorTick    = 'on';
ax.YMinorTick    = 'on';
ax.ZMinorTick    = 'on';
ax.GridLineStyle = ':';
